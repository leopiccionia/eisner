These pages are here shared for demonstration purposes only. You can't share it in any commercial unauthorized modification of the software.

They're based on Will Eisner Publications' "Baseball Comics", but the page order differs:
	TO		FROM
	01		01
	02 ~ 13 	03 ~ 14
	14		30
	15 ~ 26 	18 ~ 29
	27 ~ 30 	31 ~ 34
	31		17
	32		36

This comic is supposedly in public domain. If you know otherwise, please let me know.
Source: <http://comicbookplus.com/?dlid=41543>.